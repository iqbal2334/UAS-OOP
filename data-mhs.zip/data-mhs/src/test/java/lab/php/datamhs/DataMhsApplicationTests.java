package lab.php.datamhs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataMhsApplicationTests {

	@Test
	void contextLoads() {
	}

}
